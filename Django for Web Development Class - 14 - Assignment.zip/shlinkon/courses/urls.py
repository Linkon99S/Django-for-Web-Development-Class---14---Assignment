from django.urls import path
from . import views

urlpatterns = [
    path('', views.course),
    path('ds/', views.data_science, name='data_science'),
    path('ml/', views.machine_learning, name='machine_learning'),
    path('dl/', views.deep_learning, name='deep_learing'),
    path('bd/', views.big_data, name='big_data'),
    path('home/', views.home, name='home'),
    path('student/', views.student_info),
    path('form/', views.show_form, name='sform'),
    path('successfully/', views.success, name='successfully'),
]
