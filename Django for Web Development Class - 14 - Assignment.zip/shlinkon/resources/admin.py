from django.contrib import admin
from . models import Teacher, Student, Course

# Register your models here.

#One to One relationship
@admin.register(Teacher)
class teacAdmin(admin.ModelAdmin):
    list_display = ['teacher_name', 'teacher_reg', 'user']


#many to one
@admin.register(Student)
class stuAdmin(admin.ModelAdmin):
    list_display = ['student_name','student_reg','course','user']

#many to many
@admin.register(Course)
class courseAdmin(admin.ModelAdmin):
    list_display = ['course_name','course_code','course_teacher']