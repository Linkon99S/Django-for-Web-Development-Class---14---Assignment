from django.db import models
from django.contrib.auth.models import User

# Create your models here.

#one to one relationship
class Teacher(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    teacher_name = models.CharField(max_length=30)
    teacher_reg = models.IntegerField()


#Many To One
class Student(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    student_name = models.CharField(max_length=30)
    student_reg = models.IntegerField()
    course = models.CharField(max_length=20)


#Many To Many
class Course(models.Model):
    user = models.ManyToManyField(User)
    course_name = models.CharField(max_length=25)
    course_code = models.IntegerField()

    def course_teacher(self):
        return ",".join([str(p) for p in self.user.all()])
