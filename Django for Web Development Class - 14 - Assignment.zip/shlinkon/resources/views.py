from django.shortcuts import render, HttpResponseRedirect
from . forms import usercf
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm, SetPasswordForm
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash


# Create your views here.
def free_course(request):
    return render(request,'resources/freecourse.html', {'fcrs':5, 'platform':'S.H.Linkon'})

def blog(request):
    course1 = 'Machine Learning'
    course2 = 'Deep Learning'
    course3 = 'data analysis'
    course4 = 'Python with problem solving'
    freecourse_details={'c1':course1, 'c2':course2, 'c3':course3, 'c4':course4}
    return render(request,'resources/blog.html', freecourse_details)


#Registration
def usercform(request):
    if request.method == "POST":
        frm = usercf(request.POST)
        if frm.is_valid():
            frm.save()
    else:        
        frm = usercf()
    return render(request, 'resources/usercform.html', {'form':frm})


#Login
def login_form(request):
    if request.method == 'POST':
        frm = AuthenticationForm(request=request, data = request.POST)
        if frm.is_valid():
            uname = frm.cleaned_data['username']
            upass = frm.cleaned_data['password']
            user = authenticate(username=uname, password= upass)
            if user is not None:
                login(request, user)
                return HttpResponseRedirect('/res/sucess')
    else:
        frm = AuthenticationForm()
    return render(request, 'resources/login.html', {'form':frm})


#success login
def slogin(request):
    return render(request, 'resources/success.html')


#Logout
def logout_form(request):
    logout(request)
    return HttpResponseRedirect('/res/login')


#Change password with old Password
def password_change(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            frm = PasswordChangeForm(user = request.user, data = request.POST)
            if frm.is_valid():
                frm.save()
                update_session_auth_hash(request, frm.user)
                return HttpResponseRedirect('/res/sucess')
        else:
            frm = PasswordChangeForm(user=request.user)
            return render(request, 'resources/passc.html', {'form':frm})

    else:
        return HttpResponseRedirect('/res/login')


#Password Change without old pass
def without_old_password_change(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            frm = SetPasswordForm(user = request.user, data = request.POST)
            if frm.is_valid():
                frm.save()
                update_session_auth_hash(request, frm.user)
                return HttpResponseRedirect('/res/sucess')
        else:
            frm = SetPasswordForm(user=request.user)
            return render(request, 'resources/withoutpassc.html', {'form':frm})

    else:
        return HttpResponseRedirect('/res/login') 

    